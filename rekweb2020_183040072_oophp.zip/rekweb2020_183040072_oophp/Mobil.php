<?php 

class Mobil{
	public $nama,
	public $merk,
	public $warna,
	public $kecepatanMaksimal,
	public $jumlahPenumpang;

	public function tambahKecepatan(){
		return "Kecepatan bertambah!";
	}
}
	public function kurangKecepatan(){

	}
	public function gantiTransisi(){
		
	}
}






 ?>